setwd("C:\\Users\\it24101972\\Desktop\\IT24101972")
branch_data <- read.table("Exercise.txt",header = TRUE, sep = ",")
fix(branch_data)
str(branch_data)
attach(branch_data)

boxplot(branch_data$Sales_X1,
        main = "Boxplot - sales",
        col = "lightblue",
        ylab = "Sales")

summary(branch_data$Advertising_X2)
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

find_outliers <- function(x){
  Q1 <- quantile(x,0.25)
  Q3 <- quantile(x,0.75)
  IQR_value <- IQR(x)
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 + 1.5 * IQR_value
  outliers <- x[x <lower | x > upper]
  return(outliers)
}

find_outliers(branch_data$Years_X3)